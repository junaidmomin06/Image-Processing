function try_coloredge(im0)
    im0 = imread('JunaidImg.jpg');
    [row, col, dim] = size(im0);
    if (dim > 1)
        im = rgb2gray(im0); % Convert color image to grayscale
    else
        im = im0;
    end
    
    % Apply Gaussian smoothing
    sigma = 1; % Adjust sigma for stronger smoothing
    smoothed_im = imgaussfilt(im, sigma);
    
    % Compute gradients
    [Gx, Gy] = gradient(double(smoothed_im));
    gradient_magnitude = sqrt(Gx.^2 + Gy.^2);

    % Perform thresholding to obtain edges for custom method
    threshold_custom = 0.290 * max(gradient_magnitude(:)); % Adjust threshold for finer edges
    edge_image_custom = gradient_magnitude > threshold_custom;
    
    % Convert edge images to color images with red edges
    red_edges = cat(3, uint8(edge_image_custom) * 255, zeros(size(edge_image_custom)), zeros(size(edge_image_custom)));
   
    % Compute edges using other methods
    edge_image_sobel = edge(im, 'sobel');
    edge_image_prewitt = edge(im, 'prewitt');
    edge_image_roberts = edge(im, 'roberts');

    % Convert edge images to color images with specific colors
    sobel_edges = cat(3, zeros(size(edge_image_sobel)), zeros(size(edge_image_sobel)), uint8(edge_image_sobel) * 255);
    prewitt_edges = cat(3, zeros(size(edge_image_prewitt)), uint8(edge_image_prewitt) * 255, zeros(size(edge_image_prewitt)));

    % Resize the images for display
    resized_im = imresize(im, [row*4, col*4]);
    resized_sobel = imresize(sobel_edges, [row*4, col*4]);
    resized_prewitt = imresize(prewitt_edges, [row*4, col*4]);
    %resized_roberts = imresize(edge_image_roberts, [row*4, col*4]);
    resized_red_edges = imresize(red_edges, [row*4, col*4]);


    % Create a new figure with larger size
    figure('Position', [100, 100, 1200, 900]); % Adjust the position and size as needed

    % Display the images
    subplot(2, 2, 1);
    imshow(resized_im);
    title('Original Image');
    subplot(2, 2, 2);
    imshow(resized_sobel);
    title('Sobel Image')
    subplot(2, 2, 3);
    imshow(resized_prewitt);
    title('Prewitt');
    %subplot(2, 2, 4);
    %imshow(resized_roberts);
    %title('Roberts');
    subplot(2, 2, 4);
    imshow(resized_red_edges);
    title('Custom (Red Edges)');
end
