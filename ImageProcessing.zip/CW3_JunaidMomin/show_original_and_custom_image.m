function show_original_and_custom_image(im0)
    im0 = imread('JunaidImg.jpg');
    [row, col, dim] = size(im0);
    if (dim > 1)
        im = rgb2gray(im0); % Convert color image to grayscale
    else
        im = im0;
    end
    
    % Apply Gaussian smoothing
    sigma = 0.9; % Adjust sigma for stronger smoothing
    smoothed_im = imgaussfilt(im, sigma);
    
    % Compute gradients
    [Gx, Gy] = gradient(double(smoothed_im));
    gradient_magnitude = sqrt(Gx.^2 + Gy.^2);

    % Perform thresholding to obtain edges for custom method
    threshold_custom = 0.290 * max(gradient_magnitude(:)); % Adjust threshold for finer edges
    edge_image_custom = gradient_magnitude > threshold_custom;

    % Resize the images for display
    resize_factor = 5; % Adjust resize factor for larger images
    resized_im = imresize(im, resize_factor);
    resized_custom = imresize(edge_image_custom, resize_factor);

    % Create a new figure with larger size
    figure('Position', [100, 100, 800, 600]); % Adjust the position and size as needed

    % Display the original image and custom method image
    subplot(1, 2, 1);
    imshow(resized_im);
    title('Original Image');
    subplot(1, 2, 2);
    imshow(resized_custom);
    title('Custom Method');
end
