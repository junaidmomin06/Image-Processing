function compare_face_edges(image1_path, image2_path)
    % Read the two images
    image1 = imread(image1_path);
    image2 = imread(image2_path);
    
    % Ensure images have the same dimensions
    [height1, width1, ~] = size(image1);
    [height2, width2, ~] = size(image2);
    
    if height1 ~= height2 || width1 ~= width2
        % Crop the larger image to match the dimensions of the smaller one
        min_height = min(height1, height2);
        min_width = min(width1, width2);
        
        if height1 > height2
            image1 = image1(1:min_height, 1:min_width, :);
        else
            image2 = image2(1:min_height, 1:min_width, :);
        end
    end
    
    % Detect face edges using a custom method
    edge_custom1 = custom_edge_detection(image1);
    edge_custom2 = custom_edge_detection(image2);
    
    % Perform edge detection using Sobel method
    edge_sobel1 = edge(rgb2gray(image1), 'Sobel');
    edge_sobel2 = edge(rgb2gray(image2), 'Sobel');
    
    % Perform edge detection using Roberts method
    edge_roberts1 = edge(rgb2gray(image1), 'Roberts');
    edge_roberts2 = edge(rgb2gray(image2), 'Roberts');
    
    % Perform edge detection using Prewitt method
    edge_prewitt1 = edge(rgb2gray(image1), 'Prewitt');
    edge_prewitt2 = edge(rgb2gray(image2), 'Prewitt');
    
    % Display the original images and the detected edges using different methods
    figure;
    subplot(3, 4, 1);
    imshow(image1);
    title('Image 1');
    subplot(3, 4, 2);
    imshow(image2);
    title('Image 2');
    subplot(3, 4, 3);
    imshow(edge_custom1);
    title('Custom Method 1');
    subplot(3, 4, 4);
    imshow(edge_custom2);
    title('Custom Method 2');
    subplot(3, 4, 5);
    imshow(edge_sobel1);
    title('Sobel Method 1');
    subplot(3, 4, 6);
    imshow(edge_sobel2);
    title('Sobel Method 2');
    subplot(3, 4, 7);
    imshow(edge_roberts1);
    title('Roberts Method 1');
    subplot(3, 4, 8);
    imshow(edge_roberts2);
    title('Roberts Method 2');
    subplot(3, 4, 9);
    imshow(edge_prewitt1);
    title('Prewitt Method 1');
    subplot(3, 4, 10);
    imshow(edge_prewitt2);
    title('Prewitt Method 2');
end

function edge_image = custom_edge_detection(image)
    % Implement your custom edge detection algorithm here
    % For example, you can use the method you defined earlier
    % Dummy implementation for demonstration purpose
    [row, col, ~] = size(image);
    edge_image = zeros(row, col); % Initialize edge image
    % Apply custom edge detection algorithm
    for c = 1:3 % Iterate over each color channel
        % Apply edge detection to the current color channel
        % Example: edge_image(:,:,c) = my_custom_edge_function(image(:,:,c));
        % Fill this line with your custom edge detection algorithm
        % Let's just make a dummy edge detection for demonstration purpose
        % Here, we're setting a threshold for edge detection
        threshold = 100; % Adjust threshold as needed
        colored_edges = image(:,:,c) > threshold;
        % Add the colored edges to the edge image
        edge_image(:,:,c) = colored_edges;
    end
end



%Run below command to execute the code
%compare_face_edges('Junaid.jpg', 'Junaid1.jpg')
