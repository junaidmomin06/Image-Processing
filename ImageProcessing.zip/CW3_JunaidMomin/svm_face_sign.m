function svm_face_sign()

    % Read the original image
    junaid = imread('JunaidImg.jpg');

    % Read and resize the signature
    im0 = imread('Sign.png');
    scaling_factor = 0.5; % Adjust the scaling factor as needed
    im0_resized = imresize(im0, scaling_factor);

    % Calculate the position to impose the resized signature (top left corner)
    pos_x = 1;
    pos_y = 1;

    % Imposing the resized signature on the original image
    junaid_with_signature = junaid;
    mask = im0_resized(:, :, 1) ~= 255 | im0_resized(:, :, 2) ~= 255 | im0_resized(:, :, 3) ~= 255;
    junaid_with_signature((pos_y+1):(pos_y + size(im0_resized, 1)), (pos_x+1):(pos_x + size(im0_resized, 2)), :) = ...
        uint8(mask) .* im0_resized + uint8(~mask) .* junaid((pos_y+1):(pos_y + size(im0_resized, 1)), (pos_x+1):(pos_x + size(im0_resized, 2)), :);

    % Convert the image with the imposed signature to HSV color space
    im_hsv = rgb2hsv(junaid_with_signature);

    % Thresholding to obtain the face region
    hue_threshold = [0.01, 0.1]; % Adjust hue threshold as needed
    sat_threshold = [0.15, 1];   % Adjust saturation threshold as needed
    val_threshold = [0.2, 1];    % Adjust value threshold as needed
    face_mask = (im_hsv(:,:,1) >= hue_threshold(1) & im_hsv(:,:,1) <= hue_threshold(2)) & ...
                (im_hsv(:,:,2) >= sat_threshold(1) & im_hsv(:,:,2) <= sat_threshold(2)) & ...
                (im_hsv(:,:,3) >= val_threshold(1) & im_hsv(:,:,3) <= val_threshold(2));

    % Apply morphological operations to refine the face mask
    se = strel('disk', 3); % Adjust the disk size as needed
    face_mask_processed = imclose(face_mask, se); % Close operation to fill gaps
    face_mask_processed = imfill(face_mask_processed, 'holes'); % Fill holes

    % Combine the face mask with the original image
    junaid_with_face = junaid;
    junaid_with_face(repmat(face_mask_processed, [1, 1, 3])) = junaid_with_signature(repmat(face_mask_processed, [1, 1, 3]));

    % Perform Segmentation on detected face region
    face_region_rgb = junaid_with_face;
    face_region_rgb(face_mask_processed) = 255; % Mask out non-face pixels
    [~, ~] = imsegkmeans(uint8(face_region_rgb * 255), 3); % Perform segmentation on face region

    % Displaying results
    figure;
    subplot(2,2,1), imshow(junaid_with_face), title('Original Image');
    subplot(2,2,2), imshow(im0_resized), title('Resized Signature');
    subplot(2,2,3), imshow(junaid_with_signature), title('Image with Signature');
    subplot(2,2,4), imshow(face_mask_processed), title('Detected Face Mask');
    
end
