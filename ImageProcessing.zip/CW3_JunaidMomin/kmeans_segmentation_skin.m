function kmeans_segmentation_skin(image_path, k_values)

% Example usage:
image_path = 'JunaidImg.jpg';
k_values = [2, 3, 5, 7, 10, 6, 11, 8]; % Specify different k values
%kmeans_segmentation_skin(image_path, k_values);

    % Read the RGB image
    Irgb = imread(image_path);

    % Convert RGB image to HSV color space
    I = rgb2hsv(Irgb);

    % Create a skin mask
    skin_mask = create_skin_mask(I);

    % Apply morphological operations to refine the skin mask
    se = strel('disk', 6); % Adjust the disk size as needed
    skin_mask = imclose(skin_mask, se); % Close operation to fill gaps
    skin_mask = imfill(skin_mask, 'holes'); % Fill holes
    skin_mask = imopen(skin_mask, se); % Open operation to remove noise

    % Perform region analysis to identify connected components
    cc = bwconncomp(skin_mask);

    % Calculate properties of connected components
    stats = regionprops(cc, 'Area', 'BoundingBox');

    % Filter out small regions (e.g., neck) based on area
    min_area = 2000; % Adjust the minimum area threshold as needed
    idx_keep = [stats.Area] >= min_area;

    % Create a binary mask for the identified regions
    mask_filtered = false(size(skin_mask));
    for i = 1:length(idx_keep)
        if idx_keep(i)
            mask_filtered(cc.PixelIdxList{i}) = true;
        end
    end

    % Apply the filtered mask to the original image
    I_skin = bsxfun(@times, Irgb, cast(mask_filtered, class(Irgb)));

    % Plot original image and filtered skin mask
    figure;
    subplot(1, 2, 1);
    imshow(Irgb);
    title('Original Image');

    subplot(1, 2, 2);
    imshow(I_skin);
    title('Filtered Skin Mask');

    % Perform K-means segmentation for different k values on the filtered skin regions
    figure;
    for i = 1:numel(k_values)
        % Perform K-means clustering on the skin regions
        [L, ~] = imsegkmeans(I_skin, k_values(i));

        % Overlay segmentation labels on the skin image
        B = labeloverlay(I_skin, L);

        % Plot segmented image
        subplot(2, ceil(numel(k_values)/2), i);
        imshow(B);
        title(['K = ', num2str(k_values(i)), ' (Skin Segmentation)']);
    end

end

function skin_mask = create_skin_mask(I)
    % Define HSV color thresholds for skin detection
    hue_thresh = [0.01, 0.1]; % Hue range for skin color
    sat_thresh = [0.15, 1];   % Saturation range for skin color
    val_thresh = [0.2, 1];    % Value range for skin color

    % Create a binary mask based on the HSV thresholds
    skin_mask = (I(:,:,1) >= hue_thresh(1) & I(:,:,1) <= hue_thresh(2)) & ...
                (I(:,:,2) >= sat_thresh(1) & I(:,:,2) <= sat_thresh(2)) & ...
                (I(:,:,3) >= val_thresh(1) & I(:,:,3) <= val_thresh(2));
end


