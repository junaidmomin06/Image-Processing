function Functwithfunct(im0)
    im0 = imread('JunaidImg.jpg');
    [row, col, dim] = size(im0);
    if (dim > 1)
        im = rgb2gray(im0); % Convert color image to grayscale
    else
        im = im0;
    end
    
    % Apply Gaussian smoothing
    sigma = 1; % Adjust sigma for stronger smoothing
    smoothed_im = imgaussfilt(im, sigma);
    
    % Compute gradients
    [Gx, Gy] = gradient(double(smoothed_im));
    gradient_magnitude = sqrt(Gx.^2 + Gy.^2);

    % Perform thresholding to obtain edges for custom method
    threshold_custom = 0.290 * max(gradient_magnitude(:)); % Adjust threshold for finer edges
    edge_image_custom = gradient_magnitude > threshold_custom;

    % Compute edges using other methods
    edge_image_canny = edge(im, 'canny');
    edge_image_sobel = edge(im, 'sobel');
    edge_image_log = edge(im, 'log');
    edge_image_prewitt = edge(im, 'prewitt');
    edge_image_roberts = edge(im, 'roberts');
    edge_image_zerocross = edge(im, 'zerocross');

    % Resize the images for display
    resize_factor = 5; % Adjust resize factor for larger images
    resized_im = imresize(im, resize_factor);
    resized_custom = imresize(edge_image_custom, resize_factor);
    resized_canny = imresize(edge_image_canny, resize_factor);
    resized_sobel = imresize(edge_image_sobel, resize_factor);
    resized_log = imresize(edge_image_log, resize_factor);
    resized_prewitt = imresize(edge_image_prewitt, resize_factor);
    resized_roberts = imresize(edge_image_roberts, resize_factor);
    resized_zerocross = imresize(edge_image_zerocross, resize_factor);

    % Create a new figure with larger size
    figure('Position', [100, 100, 1200, 900]); % Adjust the position and size as needed

    % Display the images
    subplot(3, 3, 1);
    imshow(resized_im);
    title('Original Image');
    subplot(3, 3, 2);
    imshow(resized_canny);
    title('Canny');
    subplot(3, 3, 3);
    imshow(resized_sobel);
    title('Sobel');
    subplot(3, 3, 4);
    imshow(resized_log);
    title('LOG');
    subplot(3, 3, 5);
    imshow(resized_prewitt);
    title('Prewitt');
    subplot(3, 3, 6);
    imshow(resized_roberts);
    title('Roberts');
    subplot(3, 3, 7);
    imshow(resized_zerocross);
    title('Zero-Cross');
    subplot(3, 3, 8);
    imshow(resized_custom);
    title('Custom');
end
